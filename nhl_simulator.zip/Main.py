from main_menu import *
from playsound import playsound



if __name__ == "__main__":
    main_menu = MainMenu()
    main_menu.run()
